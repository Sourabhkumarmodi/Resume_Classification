from flask import Flask, request, render_template
import re
import spacy
import pickle
from docx import Document
from charset_normalizer import detect

app = Flask(__name__)

# Load SpaCy model
nlp = spacy.load("en_core_web_sm")

# Ensure the exact TF-IDF vectorizer and KNN model are loaded
try:
    with open("tfidf_vectorizer.pkl", "rb") as tfidf_file:
        tfidf_vectorizer = pickle.load(tfidf_file)

    with open("knn_model.pkl", "rb") as knn_file:
        knn_model = pickle.load(knn_file)

    with open("le.pkl", "rb") as le_file:
        label_encoder = pickle.load(le_file)
except Exception as e:
    print(f"Error loading models: {e}")


# Parsing Functions
def parse_resume(text):
    return {
        "Name": extract_name(text),
        "Email": extract_email(text),
        "Phone": extract_phone(text),
        "Skills": extract_skills(text),
        "Education": extract_education(text),
        "Experience": extract_experience(text),
        "Certifications": extract_certifications(text),
        "Parsed_Text": text,
    }

def extract_name(text):
    doc = nlp(text)
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            return ent.text.strip()
    name_pattern = r"([A-Z][a-z]+(?:\s[A-Z][a-z]+)+)"
    match = re.search(name_pattern, text)
    return match.group(1) if match else "Not Found"

def extract_email(text):
    email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
    match = re.search(email_pattern, text)
    return match.group() if match else "Not Found"

def extract_phone(text):
    phone_pattern = r"\+?\d{1,4}[-.\s]?\(?\d{1,3}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}"
    match = re.search(phone_pattern, text)
    return match.group() if match else "Not Found"

def extract_skills(text):
    # Example predefined skills
    skills_keywords = ["Python", "Java", "SQL", "React", "Data Modeling"]
    matched_skills = [skill for skill in skills_keywords if skill.lower() in text.lower()]
    return ", ".join(matched_skills) if matched_skills else "Not Found"

def extract_education(text):
    education_keywords = ["PhD", "Master", "Bachelor", "MBA"]
    for keyword in education_keywords:
        if keyword.lower() in text.lower():
            return keyword
    return "Not Found"

def extract_experience(text):
    experience_pattern = r"(\d+)\s+years?"
    match = re.search(experience_pattern, text, re.IGNORECASE)
    return f"{match.group(1)} years" if match else "Experience Not Found"

def extract_certifications(text):
    certifications_pattern = r"(?i)(?:certifications?:?\s*)([\s\S]+?)(?:\n(?:\s*\n|References|Objective|Skills|Education|Experience|Work Experience))"
    match = re.search(certifications_pattern, text)
    return match.group(1).strip() if match else "Not Found"

# Resume Classification
def classify_resume(parsed_text):
    try:
        # Transform parsed text into features
        tfidf_features = tfidf_vectorizer.transform([parsed_text])

        # Check compatibility
        if tfidf_features.shape[1] != knn_model.n_features_in_:
            return "Feature mismatch: TF-IDF vectorizer and KNN model incompatible."

        # Predict category
        category_index = knn_model.predict(tfidf_features)[0]
        return label_encoder.inverse_transform([category_index])[0]

    except Exception as e:
        return f"Classification error: {e}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    texts = []

    if 'resume_file' in request.files:
        files = request.files.getlist('resume_file')
        for file in files:
            if file.filename.endswith('.docx'):
                try:
                    doc = Document(file)
                    texts.append('\n'.join([p.text for p in doc.paragraphs]))
                except Exception as e:
                    return render_template('index.html', error=f"Error reading .docx file: {e}")
            else:
                try:
                    raw_data = file.read()
                    detected = detect(raw_data)
                    encoding = detected['encoding']
                    texts.append(raw_data.decode(encoding))
                except UnicodeDecodeError:
                    return render_template('index.html', error="Unsupported file encoding.")
    text_input = request.form.get('resume_text', '')
    if text_input.strip():
        texts.append(text_input)

    if not texts:
        return render_template('index.html', error="Please upload files or paste resume text.")

    parsed_resumes = []
    for text in texts:
        parsed_details = parse_resume(text)
        parsed_details["Category"] = classify_resume(parsed_details["Parsed_Text"])
        parsed_resumes.append(parsed_details)

    return render_template('index.html', parsed_resumes=parsed_resumes)

@app.route('/clear', methods=['POST'])
def clear():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
